import { useState, useEffect } from 'react';
import axios from 'axios';

export const useCitySearch = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    const searchCities = async () => {
      if (!query || query.length < 3) {
        setResults([]);
        return;
      }
      setSearching(true);
      try {
        // Limit to Pakistan by countrycodes=pk
        const res = await axios.get(`https://nominatim.openstreetmap.org/search?q=${query}&format=json&countrycodes=pk&limit=5`);
        setResults(res.data.map(item => ({
          city: item.name,
          display_name: item.display_name,
          lat: parseFloat(item.lat),
          lon: parseFloat(item.lon)
        })));
      } catch (err) {
        console.error("City search failed", err);
      } finally {
        setSearching(false);
      }
    };

    const delayDebounceFn = setTimeout(() => {
      searchCities();
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  return { query, setQuery, results, setResults, searching };
};

import { useState, useEffect } from 'react';
import { getCurrentWeather, getAirPollution } from '../services/weatherService';
import { getAQIByCoordinates } from '../services/waqiService';

export const useRealtimeData = (lat, lon) => {
  const [data, setData] = useState({
    weather: null,
    pollution: null,
    waqi: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let isMounted = true;
    
    const fetchData = async () => {
      if (!lat || !lon) return;
      
      setData(prev => ({ ...prev, loading: true, error: null }));
      
      try {
        const [weatherRes, pollutionRes, waqiRes] = await Promise.allSettled([
          getCurrentWeather(lat, lon),
          getAirPollution(lat, lon),
          getAQIByCoordinates(lat, lon)
        ]);

        if (!isMounted) return;

        // Fallback to mock data if API fails (e.g. missing keys)
        const weather = weatherRes.status === 'fulfilled' ? weatherRes.value : {
          main: { temp: Math.round(25 + Math.random() * 15), humidity: Math.round(30 + Math.random() * 40) },
          wind: { speed: Math.round(Math.random() * 10) }
        };
        
        const pollution = pollutionRes.status === 'fulfilled' ? pollutionRes.value : {
          list: [{ components: { pm2_5: Math.round(50 + Math.random() * 150), pm10: Math.round(80 + Math.random() * 200) } }]
        };
        
        const waqi = waqiRes.status === 'fulfilled' ? waqiRes.value : {
          aqi: Math.round(pollution.list[0].components.pm2_5 * 1.5) // Approximate AQI
        };

        setData({
          weather,
          pollution,
          waqi,
          loading: false,
          error: null,
        });

      } catch (err) {
        if (isMounted) {
          setData(prev => ({ ...prev, loading: false, error: err.message }));
        }
      }
    };

    fetchData();

    // Refresh every 15 minutes
    const interval = setInterval(fetchData, 15 * 60 * 1000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [lat, lon]);

  return data;
};


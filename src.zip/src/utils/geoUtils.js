export const calculateAQIColor = (aqi) => {
  if (aqi <= 50) return '#22c55e'; // Green
  if (aqi <= 100) return '#eab308'; // Yellow
  if (aqi <= 150) return '#f97316'; // Orange
  if (aqi <= 200) return '#ef4444'; // Red
  return '#7f1d1d'; // Dark Red
};

export const getRiskLabel = (aqi) => {
  if (aqi <= 50) return 'Good';
  if (aqi <= 100) return 'Moderate';
  if (aqi <= 150) return 'Unhealthy for Sensitive Groups';
  if (aqi <= 200) return 'Unhealthy';
  if (aqi <= 300) return 'Very Unhealthy';
  return 'Hazardous';
};

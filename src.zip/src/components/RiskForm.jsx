import React, { useState } from "react"
import { Activity, AlertCircle } from "lucide-react"
import { predictRisk } from "../services/api"

function RiskForm({ selectedCity, pm25 }) {
    const [age, setAge] = useState("")
    const [asthma, setAsthma] = useState(false)
    const [outdoorJob, setOutdoorJob] = useState(false)
    const [heartDisease, setHeartDisease] = useState(false)
    const [copd, setCopd] = useState(false)
    const [smoking, setSmoking] = useState(false)
    const [result, setResult] = useState(null)
    const [loading, setLoading] = useState(false)

    async function calculateRisk() {
        if (!age) return;
        setLoading(true)
        try {
            const response = await predictRisk({
                age: parseInt(age),
                has_asthma: asthma,
                has_copd: copd,
                is_smoker: smoking,
                has_heart_disease: heartDisease,
                outdoor_job: outdoorJob,
                current_pm25: pm25,
                city: selectedCity.city
            })
            setResult(response)
        } catch (error) {
            setResult({ predicted_risk: "Error", recommendation: "Could not connect to AI service." })
        }
        setLoading(false)
    }

    const getRiskColor = (risk) => {
        if (!risk) return '';
        if (risk.includes("Low")) return "text-green-400 bg-green-500/10 border-green-500/30";
        if (risk.includes("Moderate")) return "text-yellow-400 bg-yellow-500/10 border-yellow-500/30";
        if (risk.includes("High")) return "text-orange-400 bg-orange-500/10 border-orange-500/30";
        return "text-red-400 bg-red-500/10 border-red-500/30";
    }

    return (
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 backdrop-blur-md shadow-2xl h-full flex flex-col">
            <div className="mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                    <Activity className="text-cyan-400" />
                    AI Health Risk Profile
                </h2>
                <p className="text-slate-400 mt-2 text-sm">
                    Personalized risk assessment based on your health factors and current {selectedCity.city} air quality.
                </p>
            </div>

            <div className="flex-grow space-y-4">
                <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1 uppercase tracking-wider">Age</label>
                    <input
                        type="number"
                        placeholder="Enter your age"
                        value={age}
                        onChange={(e) => setAge(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 shadow-inner"
                    />
                </div>

                <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-2.5 rounded-lg cursor-pointer hover:bg-slate-700 transition">
                        <input type="checkbox" checked={asthma} onChange={(e) => setAsthma(e.target.checked)} className="form-checkbox h-4 w-4 text-cyan-500 rounded border-slate-600 bg-slate-900 focus:ring-cyan-500" />
                        <span className="text-sm font-medium">Asthma</span>
                    </label>
                    <label className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-2.5 rounded-lg cursor-pointer hover:bg-slate-700 transition">
                        <input type="checkbox" checked={copd} onChange={(e) => setCopd(e.target.checked)} className="form-checkbox h-4 w-4 text-cyan-500 rounded border-slate-600 bg-slate-900 focus:ring-cyan-500" />
                        <span className="text-sm font-medium">COPD</span>
                    </label>
                    <label className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-2.5 rounded-lg cursor-pointer hover:bg-slate-700 transition">
                        <input type="checkbox" checked={heartDisease} onChange={(e) => setHeartDisease(e.target.checked)} className="form-checkbox h-4 w-4 text-cyan-500 rounded border-slate-600 bg-slate-900 focus:ring-cyan-500" />
                        <span className="text-sm font-medium">Heart Disease</span>
                    </label>
                    <label className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-2.5 rounded-lg cursor-pointer hover:bg-slate-700 transition">
                        <input type="checkbox" checked={smoking} onChange={(e) => setSmoking(e.target.checked)} className="form-checkbox h-4 w-4 text-cyan-500 rounded border-slate-600 bg-slate-900 focus:ring-cyan-500" />
                        <span className="text-sm font-medium">Smoker</span>
                    </label>
                    <label className="flex items-center space-x-3 bg-slate-800 border border-slate-700 p-2.5 rounded-lg cursor-pointer hover:bg-slate-700 transition col-span-2">
                        <input type="checkbox" checked={outdoorJob} onChange={(e) => setOutdoorJob(e.target.checked)} className="form-checkbox h-4 w-4 text-cyan-500 rounded border-slate-600 bg-slate-900 focus:ring-cyan-500" />
                        <span className="text-sm font-medium">Outdoor Job / Activity</span>
                    </label>
                </div>
            </div>

            <button
                onClick={calculateRisk}
                disabled={loading || !age}
                className="w-full mt-6 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold px-6 py-3 rounded-xl shadow-lg transition-all"
            >
                {loading ? "Analyzing Factors..." : "Predict AI Risk"}
            </button>

            {result && (
                <div className={`mt-5 border rounded-xl p-4 transition-all ${getRiskColor(result.predicted_risk)}`}>
                    <div className="flex items-start gap-3">
                        <AlertCircle className="shrink-0 mt-0.5" size={20} />
                        <div>
                            <div className="font-bold text-lg mb-1">{result.predicted_risk}</div>
                            <div className="text-sm opacity-90">{result.recommendation}</div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

export default RiskForm
import React, { useEffect, useState } from "react";
import {
  MapContainer,
  TileLayer,
  GeoJSON,
  useMap,
  Circle,
  Popup,
  Tooltip,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { cityAreaAQI } from "../data/cityAreaAQI";

function ChangeView({ center, zoom }) {
  const map = useMap();

  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);

  return null;
}

function getAQIColor(aqi) {
  if (aqi <= 50) return "#22c55e";
  if (aqi <= 100) return "#eab308";
  if (aqi <= 150) return "#f97316";
  if (aqi <= 200) return "#ef4444";
  return "#7f1d1d";
}

function getAQILabel(aqi) {
  if (aqi <= 50) return "Good / Safe";
  if (aqi <= 100) return "Moderate";
  if (aqi <= 150) return "Unhealthy for Sensitive People";
  if (aqi <= 200) return "Unhealthy";
  return "Very Dangerous";
}

function PollutionMap({ selectedCity }) {
  const [geoData, setGeoData] = useState(null);
  const [mode, setMode] = useState("currentAQI");

  useEffect(() => {
    fetch("/data/pakistan_cities.geojson")
      .then((res) => res.json())
      .then((data) => setGeoData(data))
      .catch((err) => console.error("Could not load GeoJSON", err));
  }, []);

  const centerCoords = selectedCity
    ? [selectedCity.lat, selectedCity.lon]
    : [31.5204, 74.3587];

  const cityName = selectedCity?.city || "Lahore";
  const areaZones = cityAreaAQI[cityName] || cityAreaAQI.Lahore;

  const geoJsonStyle = {
    color: "#06b6d4",
    weight: 2,
    opacity: 0.5,
    fillOpacity: 0.05,
  };

  const getModeTitle = () => {
    if (mode === "currentAQI") return "Current AQI";
    if (mode === "predicted6hAQI") return "Next 6 Hours";
    return "Next 24 Hours";
  };

  return (
    <div className="relative h-full w-full">
      <div className="absolute top-4 left-4 z-[1000] bg-slate-900/90 border border-slate-700 rounded-xl p-2 flex gap-2">
        <button
          onClick={() => setMode("currentAQI")}
          className={`px-3 py-1 rounded-lg text-xs font-semibold ${
            mode === "currentAQI"
              ? "bg-cyan-500 text-white"
              : "bg-slate-800 text-slate-300"
          }`}
        >
          Current
        </button>

        <button
          onClick={() => setMode("predicted6hAQI")}
          className={`px-3 py-1 rounded-lg text-xs font-semibold ${
            mode === "predicted6hAQI"
              ? "bg-cyan-500 text-white"
              : "bg-slate-800 text-slate-300"
          }`}
        >
          +6 Hrs
        </button>

        <button
          onClick={() => setMode("predicted24hAQI")}
          className={`px-3 py-1 rounded-lg text-xs font-semibold ${
            mode === "predicted24hAQI"
              ? "bg-cyan-500 text-white"
              : "bg-slate-800 text-slate-300"
          }`}
        >
          +24 Hrs
        </button>
      </div>

      <MapContainer
        center={centerCoords}
        zoom={11}
        className="h-full w-full rounded-3xl"
      >
        <ChangeView center={centerCoords} zoom={11} />

        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; OpenStreetMap contributors &copy; CARTO'
        />

        {geoData && <GeoJSON data={geoData} style={geoJsonStyle} />}

        {areaZones.map((area, index) => {
          const aqi = area[mode];
          const color = getAQIColor(aqi);

          return (
            <Circle
              key={index}
              center={[area.lat, area.lon]}
              radius={1800}
              pathOptions={{
                color,
                fillColor: color,
                fillOpacity: 0.38,
                opacity: 0.9,
                weight: 2,
              }}
            >
              <Tooltip permanent direction="center" className="aqi-tooltip">
                {area.name}
              </Tooltip>

              <Popup>
                <div>
                  <h3 style={{ fontWeight: "bold", marginBottom: "6px" }}>
                    {area.name}
                  </h3>
                  <p>
                    <strong>{getModeTitle()}:</strong> {aqi}
                  </p>
                  <p>
                    <strong>Status:</strong> {getAQILabel(aqi)}
                  </p>
                </div>
              </Popup>
            </Circle>
          );
        })}
      </MapContainer>

      <div className="absolute bottom-4 left-4 z-[1000] bg-slate-900/90 border border-slate-700 rounded-xl p-3 text-xs text-white space-y-1">
        <div className="font-bold mb-1">AQI Color Guide</div>
        <div><span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>Good</div>
        <div><span className="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>Moderate</div>
        <div><span className="inline-block w-3 h-3 bg-orange-500 rounded-full mr-2"></span>Unhealthy Sensitive</div>
        <div><span className="inline-block w-3 h-3 bg-red-500 rounded-full mr-2"></span>Unhealthy</div>
        <div><span className="inline-block w-3 h-3 bg-red-900 rounded-full mr-2"></span>Very Dangerous</div>
      </div>
    </div>
  );
}

export default PollutionMap;
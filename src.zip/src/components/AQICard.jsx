import React from "react"

function AQICard({ icon, title, value, label }) {
    return (
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-5 shadow-xl hover:scale-105 hover:bg-slate-800/50 hover:shadow-cyan-500/10 transition-all duration-300 backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
                <p className="text-slate-400 text-sm font-medium tracking-wide uppercase">
                    {title}
                </p>
                <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/50">
                    {icon}
                </div>
            </div>

            <h2 className="text-3xl font-extrabold text-white tracking-tight">
                {value}
            </h2>

            <p className="text-slate-500 text-sm mt-2 font-medium">
                {label}
            </p>
        </div>
    )
}

export default AQICard
import React, { useEffect, useState } from "react"
import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid
} from "recharts"
import { useAppState } from "../context/AppStateContext"
import { predictFutureAQI } from "../services/api"

function AQIChart() {
    const { realtimeData } = useAppState();
    const { weather, pollution, waqi } = realtimeData;
    const [chartData, setChartData] = useState([]);

    useEffect(() => {
        const fetchPredictions = async () => {
            if (!weather || !pollution) return;
            
            const currentAQI = waqi?.aqi || pollution?.list[0]?.components?.pm2_5 || 100;
            const pm25 = pollution.list[0].components.pm2_5;
            const pm10 = pollution.list[0].components.pm10;
            const temp = weather.main.temp;
            const humidity = weather.main.humidity;
            const wind_speed = weather.wind.speed;

            try {
                const res = await predictFutureAQI({
                    current_aqi: currentAQI,
                    pm25, pm10, temp, humidity, wind_speed
                });

                const now = new Date();
                const d = [
                    { time: "Now", aqi: Math.round(currentAQI) },
                    { time: "+6 Hrs", aqi: Math.round(res.aqi_6h) },
                    { time: "+24 Hrs", aqi: Math.round(res.aqi_24h) }
                ];
                setChartData(d);

            } catch (err) {
                console.error("Failed to fetch ML predictions", err);
                // Fallback dummy trend if backend fails
                setChartData([
                    { time: "Now", aqi: Math.round(currentAQI) },
                    { time: "+6 Hrs", aqi: Math.round(currentAQI * 1.1) },
                    { time: "+24 Hrs", aqi: Math.round(currentAQI * 0.9) }
                ]);
            }
        };

        fetchPredictions();
    }, [weather, pollution, waqi]);

    if (!chartData.length) return <div className="h-64 flex items-center justify-center text-slate-500">Waiting for data...</div>;

    // Determine gradient color based on current AQI trend
    const peakAqi = Math.max(...chartData.map(d => d.aqi));
    const strokeColor = peakAqi > 150 ? "#ef4444" : peakAqi > 100 ? "#f97316" : "#22c55e";

    return (
        <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                        <linearGradient id="colorAqi" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={strokeColor} stopOpacity={0.4}/>
                            <stop offset="95%" stopColor={strokeColor} stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="time" stroke="#64748b" tick={{fill: '#64748b'}} axisLine={false} tickLine={false} />
                    <YAxis stroke="#64748b" tick={{fill: '#64748b'}} axisLine={false} tickLine={false} />
                    <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                        itemStyle={{ color: '#e2e8f0' }}
                    />
                    <Area
                        type="monotone"
                        dataKey="aqi"
                        stroke={strokeColor}
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorAqi)"
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    )
}

export default AQIChart
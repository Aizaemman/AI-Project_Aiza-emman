import React, { useState, useRef, useEffect } from "react"
import { chatWithAI } from "../services/api"
import { Send, Trash2, Bot, User, Loader2 } from "lucide-react"

function Chatbot() {
    const [messages, setMessages] = useState([])
    const [input, setInput] = useState("")
    const [isTyping, setIsTyping] = useState(false)
    const messagesEndRef = useRef(null)

    const starterSuggestions = [
        "What is AQI?",
        "Is Lahore pollution dangerous?",
        "How does smog affect lungs?",
        "What is PM2.5?",
        "Is it safe to exercise outside?",
        "What is today's weather?",
        "Why is this project helpful?"
    ]

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }

    useEffect(() => {
        scrollToBottom()
    }, [messages, isTyping])

    const handleSend = async (text) => {
        if (!text.trim()) return

        const userMessage = { role: "user", text, timestamp: new Date() }
        setMessages((prev) => [...prev, userMessage])
        setInput("")
        setIsTyping(true)

        try {
            const response = await chatWithAI(text)
            const aiMessage = { role: "ai", text: response.reply, timestamp: new Date() }
            setMessages((prev) => [...prev, aiMessage])
        } catch (error) {
            const fallbackMessage = { role: "ai", text: "I am having trouble connecting to my servers right now.", timestamp: new Date() }
            setMessages((prev) => [...prev, fallbackMessage])
        } finally {
            setIsTyping(false)
        }
    }

    const handleKeyDown = (e) => {
        if (e.key === "Enter") {
            e.preventDefault()
            handleSend(input)
        }
    }

    const clearChat = () => setMessages([])

    const formatTime = (date) => {
        return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }

    return (
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 mt-8 flex flex-col h-[600px] shadow-2xl backdrop-blur-md">
            {/* Header */}
            <div className="flex justify-between items-center mb-5 pb-4 border-b border-slate-800">
                <div>
                    <h2 className="text-2xl font-bold flex items-center gap-2 text-cyan-400">
                        <Bot className="w-6 h-6" />
                        AI Assistant
                    </h2>
                    <p className="text-slate-400 mt-1 text-sm">
                        Powered by Gemini • AirSense Pakistan
                    </p>
                </div>
                <button
                    onClick={clearChat}
                    className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                    title="Clear Chat"
                >
                    <Trash2 className="w-5 h-5" />
                </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto pr-2 space-y-4 custom-scrollbar">
                {messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center space-y-6">
                        <div className="w-16 h-16 bg-cyan-500/10 rounded-full flex items-center justify-center text-cyan-400">
                            <Bot className="w-8 h-8" />
                        </div>
                        <p className="text-slate-400 max-w-md">
                            I am your AirSense AI Health Assistant. Ask me about air quality, pollution risks, or general health safety!
                        </p>
                        <div className="flex flex-wrap justify-center gap-2 mt-4 max-w-lg">
                            {starterSuggestions.map((suggestion, idx) => (
                                <button
                                    key={idx}
                                    onClick={() => handleSend(suggestion)}
                                    className="bg-slate-800 hover:bg-slate-700 text-cyan-300 text-sm py-2 px-4 rounded-full transition-colors border border-slate-700 hover:border-cyan-500/50"
                                >
                                    {suggestion}
                                </button>
                            ))}
                        </div>
                    </div>
                ) : (
                    messages.map((msg, index) => (
                        <div
                            key={index}
                            className={`flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}
                        >
                            <div className="flex items-end gap-2 max-w-[85%] md:max-w-[75%]">
                                {msg.role === "ai" && (
                                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 flex-shrink-0 mb-1">
                                        <Bot className="w-5 h-5" />
                                    </div>
                                )}
                                
                                <div
                                    className={`px-4 py-3 rounded-2xl ${
                                        msg.role === "user"
                                            ? "bg-cyan-600 text-white rounded-br-sm"
                                            : "bg-slate-800 border border-slate-700 text-slate-200 rounded-bl-sm"
                                    }`}
                                >
                                    <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                                </div>
                                
                                {msg.role === "user" && (
                                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-slate-300 flex-shrink-0 mb-1">
                                        <User className="w-5 h-5" />
                                    </div>
                                )}
                            </div>
                            <span className="text-xs text-slate-500 mt-1 px-11">
                                {formatTime(msg.timestamp)}
                            </span>
                        </div>
                    ))
                )}

                {isTyping && (
                    <div className="flex flex-col items-start">
                        <div className="flex items-end gap-2">
                            <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400 flex-shrink-0 mb-1">
                                <Bot className="w-5 h-5" />
                            </div>
                            <div className="px-4 py-4 rounded-2xl bg-slate-800 border border-slate-700 text-slate-200 rounded-bl-sm flex gap-1">
                                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="mt-4 pt-4 border-t border-slate-800 flex gap-2">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type your message..."
                    className="flex-1 bg-slate-950 border border-slate-700 text-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all placeholder:text-slate-600"
                    disabled={isTyping}
                />
                <button
                    onClick={() => handleSend(input)}
                    disabled={isTyping || !input.trim()}
                    className="bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed text-slate-950 p-3 rounded-xl transition-colors flex items-center justify-center"
                >
                    {isTyping ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6" />}
                </button>
            </div>
        </div>
    )
}

export default Chatbot
import React, { useEffect, useRef, useState } from "react";
import { useAppState } from "../context/AppStateContext";
import { Search } from "lucide-react";

const SearchBar = () => {
  const { setSelectedCity, predefinedCities, selectedCity } = useAppState();
  const [query, setQuery] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const wrapperRef = useRef(null);

  const filteredCities = predefinedCities.filter((city) =>
    city.city.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (city) => {
    setSelectedCity(city);
    setQuery("");
    setShowDropdown(false);
  };

  return (
    <div ref={wrapperRef} className="relative w-full max-w-sm z-50">
      <div className="relative flex items-center">
        <Search className="absolute left-3 text-slate-400" size={18} />

        <input
          type="text"
          value={query}
          onFocus={() => setShowDropdown(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowDropdown(true);
          }}
          placeholder={`Search city... Current: ${selectedCity.city}`}
          className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-cyan-500 placeholder-slate-400 shadow-inner"
        />
      </div>

      {showDropdown && (
        <ul className="absolute mt-2 w-full bg-slate-900 border border-slate-700 rounded-xl shadow-xl max-h-72 overflow-y-auto">
          {filteredCities.length > 0 ? (
            filteredCities.map((city, index) => (
              <li
                key={index}
                onClick={() => handleSelect(city)}
                className="px-4 py-3 hover:bg-slate-800 cursor-pointer text-sm border-b border-slate-800 last:border-0"
              >
                <div className="font-semibold text-white">{city.city}</div>
                <div className="text-xs text-slate-400">{city.display_name}</div>
              </li>
            ))
          ) : (
            <li className="px-4 py-3 text-sm text-slate-400">
              No city found
            </li>
          )}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;
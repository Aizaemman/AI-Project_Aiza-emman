import React from "react"
import PollutionMap from "./components/PollutionMap"
import AQIChart from "./components/AQIChart"
import AQICard from "./components/AQICard"
import RiskForm from "./components/RiskForm"
import Chatbot from "./components/Chatbot"
import SearchBar from "./components/SearchBar"
import { useAppState } from "./context/AppStateContext"
import { getRiskLabel } from "./utils/geoUtils"

import {
  Activity,
  Wind,
  Thermometer,
  AlertTriangle,
  Droplets,
  Loader
} from "lucide-react"

function App() {
  const { selectedCity, realtimeData } = useAppState()
  const { weather, pollution, waqi, loading, error } = realtimeData

  const currentAQI =
    waqi?.aqi ||
    pollution?.list?.[0]?.components?.pm2_5 ||
    0

  const pm25 = pollution?.list?.[0]?.components?.pm2_5 || 0
  const temp = weather?.main?.temp || 0
  const humidity = weather?.main?.humidity || 0

  const riskLabel = getRiskLabel(currentAQI)

  // AQI Categories
  const isGood = currentAQI <= 50
  const isModerate = currentAQI > 50 && currentAQI <= 100
  const isUnhealthy = currentAQI > 100 && currentAQI <= 150
  const isHazardous = currentAQI > 150

  const getBannerStyle = () => {
    if (isHazardous) {
      return "bg-red-500/10 border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.1)]"
    }

    if (isUnhealthy) {
      return "bg-orange-500/10 border-orange-500/30 shadow-[0_0_15px_rgba(249,115,22,0.1)]"
    }

    if (isModerate) {
      return "bg-yellow-500/10 border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)]"
    }

    return "bg-green-500/10 border-green-500/30 shadow-[0_0_15px_rgba(34,197,94,0.1)]"
  }

  const getBannerIconColor = () => {
    if (isHazardous) return "text-red-400"
    if (isUnhealthy) return "text-orange-400"
    if (isModerate) return "text-yellow-400"
    return "text-green-400"
  }

  const getBannerTextColor = () => {
    if (isHazardous) return "text-red-200"
    if (isUnhealthy) return "text-orange-200"
    if (isModerate) return "text-yellow-200"
    return "text-green-200"
  }

  const getBannerMessage = () => {
    if (isHazardous) {
      return `Hazardous air quality detected in ${selectedCity.city}. Limit outdoor exposure and wear a mask.`
    }

    if (isUnhealthy) {
      return `Unhealthy air quality detected in ${selectedCity.city}. Sensitive groups should take precautions.`
    }

    if (isModerate) {
      return `Moderate air quality in ${selectedCity.city}. Outdoor activities are generally safe.`
    }

    return `Air quality is good today in ${selectedCity.city}.`
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 selection:bg-cyan-500/30">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
          <div>
            <h1 className="text-4xl font-extrabold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent tracking-tight">
              AirSense Pakistan
            </h1>

            <p className="text-slate-400 mt-2 font-medium flex items-center gap-2">
              <Activity size={16} className="text-cyan-400" />
              Real-time AI Environmental Monitoring
            </p>
          </div>

          <div className="w-full sm:w-72">
            <SearchBar />
          </div>
        </header>

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center p-8 border border-slate-800 rounded-2xl bg-slate-900/50">
            <Loader className="animate-spin text-cyan-400 mr-3" />
            <span>
              Fetching live atmospheric data for {selectedCity.city}...
            </span>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="flex items-center justify-center p-8 border border-red-500/30 rounded-2xl bg-red-500/10 text-red-200">
            <AlertTriangle className="mr-3" />
            <span>{error}</span>
          </div>
        )}

        {!loading && !error && (
          <>
            {/* Alert Banner */}
            <div
              className={`backdrop-blur-md border rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 transition-all duration-500 ${getBannerStyle()}`}
            >
              <div className="flex items-center gap-3">
                <AlertTriangle className={getBannerIconColor()} />

                <p className={getBannerTextColor()}>
                  {getBannerMessage()}
                </p>
              </div>

              <div className="text-sm font-medium px-3 py-1 rounded-full bg-slate-900/50">
                Last updated: {new Date().toLocaleTimeString()}
              </div>
            </div>

            {/* Dashboard Cards */}
            <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <AQICard
                icon={<Activity className="text-cyan-400" />}
                title="Current AQI"
                value={currentAQI}
                label={riskLabel}
              />

              <AQICard
                icon={<Wind className="text-purple-400" />}
                title="PM2.5"
                value={`${pm25} µg/m³`}
                label="Fine Particles"
              />

              <AQICard
                icon={<Thermometer className="text-orange-400" />}
                title="Temperature"
                value={`${temp}°C`}
                label="Feels Like"
              />

              <AQICard
                icon={<Droplets className="text-blue-400" />}
                title="Humidity"
                value={`${humidity}%`}
                label="Moisture"
              />
            </section>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

              <div className="lg:col-span-2 space-y-6">

                <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-1 overflow-hidden shadow-2xl relative h-[500px]">
                  <PollutionMap
                    selectedCity={selectedCity}
                    currentAQI={currentAQI}
                  />
                </div>

                <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 shadow-2xl">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Activity className="text-cyan-400" />
                    AI Forecast (Next 24h)
                  </h3>

                  <AQIChart selectedCity={selectedCity} />
                </div>
              </div>

              <div>
                <RiskForm
                  selectedCity={selectedCity}
                  pm25={pm25}
                />
              </div>
            </div>

            <Chatbot />
          </>
        )}
      </div>
    </div>
  )
}

export default App
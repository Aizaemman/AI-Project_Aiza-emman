export const cityAreaAQI = {
  Lahore: [
    { name: "Gulberg", lat: 31.5206, lon: 74.3587, currentAQI: 95, predicted6hAQI: 120, predicted24hAQI: 145 },
    { name: "Model Town", lat: 31.4833, lon: 74.3250, currentAQI: 85, predicted6hAQI: 105, predicted24hAQI: 130 },
    { name: "Johar Town", lat: 31.4697, lon: 74.2728, currentAQI: 105, predicted6hAQI: 135, predicted24hAQI: 160 },
    { name: "DHA", lat: 31.4620, lon: 74.4090, currentAQI: 75, predicted6hAQI: 95, predicted24hAQI: 115 },
    { name: "Shahdara", lat: 31.6230, lon: 74.3045, currentAQI: 165, predicted6hAQI: 190, predicted24hAQI: 220 },
    { name: "Ravi Road", lat: 31.5880, lon: 74.3150, currentAQI: 155, predicted6hAQI: 180, predicted24hAQI: 205 },
    { name: "Township", lat: 31.4504, lon: 74.3055, currentAQI: 115, predicted6hAQI: 140, predicted24hAQI: 170 },
    { name: "Mall Road", lat: 31.5580, lon: 74.3290, currentAQI: 135, predicted6hAQI: 160, predicted24hAQI: 185 },
    { name: "Industrial Area", lat: 31.5680, lon: 74.2550, currentAQI: 190, predicted6hAQI: 220, predicted24hAQI: 250 },
  ],

  Karachi: [
    { name: "Clifton", lat: 24.8138, lon: 67.0299, currentAQI: 90, predicted6hAQI: 110, predicted24hAQI: 130 },
    { name: "Saddar", lat: 24.8550, lon: 67.0200, currentAQI: 130, predicted6hAQI: 155, predicted24hAQI: 180 },
    { name: "Korangi Industrial Area", lat: 24.8260, lon: 67.1300, currentAQI: 180, predicted6hAQI: 210, predicted24hAQI: 240 },
    { name: "Gulshan-e-Iqbal", lat: 24.9200, lon: 67.0900, currentAQI: 120, predicted6hAQI: 145, predicted24hAQI: 165 },
    { name: "North Nazimabad", lat: 24.9420, lon: 67.0470, currentAQI: 110, predicted6hAQI: 135, predicted24hAQI: 155 },
  ],

  Islamabad: [
    { name: "Blue Area", lat: 33.7150, lon: 73.0650, currentAQI: 70, predicted6hAQI: 85, predicted24hAQI: 95 },
    { name: "F-7", lat: 33.7200, lon: 73.0550, currentAQI: 55, predicted6hAQI: 70, predicted24hAQI: 80 },
    { name: "I-9 Industrial Area", lat: 33.6600, lon: 73.0600, currentAQI: 120, predicted6hAQI: 145, predicted24hAQI: 165 },
    { name: "G-10", lat: 33.6750, lon: 73.0150, currentAQI: 75, predicted6hAQI: 95, predicted24hAQI: 110 },
  ],
    Multan: [
    { name: "Cantt", lat: 30.1978, lon: 71.4711, currentAQI: 95, predicted6hAQI: 115, predicted24hAQI: 135 },
    { name: "Gulgasht Colony", lat: 30.2250, lon: 71.4750, currentAQI: 105, predicted6hAQI: 130, predicted24hAQI: 150 },
    { name: "Shah Rukn-e-Alam", lat: 30.1900, lon: 71.5000, currentAQI: 125, predicted6hAQI: 145, predicted24hAQI: 170 },
    { name: "Mumtazabad", lat: 30.1700, lon: 71.4550, currentAQI: 140, predicted6hAQI: 165, predicted24hAQI: 190 },
    { name: "Industrial Estate", lat: 30.1500, lon: 71.4300, currentAQI: 180, predicted6hAQI: 210, predicted24hAQI: 240 },
    { name: "Boson Road", lat: 30.2400, lon: 71.4850, currentAQI: 115, predicted6hAQI: 140, predicted24hAQI: 160 },
  ],

  Faisalabad: [
    { name: "D Ground", lat: 31.4200, lon: 73.0800, currentAQI: 130, predicted6hAQI: 155, predicted24hAQI: 180 },
    { name: "Madina Town", lat: 31.3950, lon: 73.0950, currentAQI: 110, predicted6hAQI: 135, predicted24hAQI: 160 },
    { name: "People Colony", lat: 31.4300, lon: 73.1050, currentAQI: 125, predicted6hAQI: 150, predicted24hAQI: 175 },
    { name: "Samanabad", lat: 31.3900, lon: 73.0650, currentAQI: 145, predicted6hAQI: 170, predicted24hAQI: 195 },
    { name: "Industrial Area", lat: 31.4550, lon: 73.1300, currentAQI: 190, predicted6hAQI: 220, predicted24hAQI: 250 },
  ],

  Peshawar: [
    { name: "University Town", lat: 34.0000, lon: 71.4850, currentAQI: 100, predicted6hAQI: 125, predicted24hAQI: 145 },
    { name: "Hayatabad", lat: 33.9850, lon: 71.4350, currentAQI: 90, predicted6hAQI: 110, predicted24hAQI: 130 },
    { name: "Saddar", lat: 34.0100, lon: 71.5600, currentAQI: 135, predicted6hAQI: 160, predicted24hAQI: 185 },
    { name: "Ring Road", lat: 34.0300, lon: 71.5900, currentAQI: 155, predicted6hAQI: 180, predicted24hAQI: 210 },
    { name: "Industrial Estate", lat: 34.0600, lon: 71.5350, currentAQI: 175, predicted6hAQI: 205, predicted24hAQI: 235 },
  ],

  Quetta: [
    { name: "Cantt", lat: 30.1900, lon: 66.9900, currentAQI: 85, predicted6hAQI: 100, predicted24hAQI: 120 },
    { name: "Satellite Town", lat: 30.2000, lon: 67.0200, currentAQI: 110, predicted6hAQI: 130, predicted24hAQI: 150 },
    { name: "Jinnah Road", lat: 30.1850, lon: 66.9950, currentAQI: 125, predicted6hAQI: 145, predicted24hAQI: 165 },
    { name: "Sariab Road", lat: 30.1550, lon: 66.9600, currentAQI: 150, predicted6hAQI: 175, predicted24hAQI: 200 },
    { name: "Industrial Area", lat: 30.2300, lon: 66.9600, currentAQI: 170, predicted6hAQI: 200, predicted24hAQI: 230 },
  ],

  Rawalpindi: [
    { name: "Saddar", lat: 33.5950, lon: 73.0550, currentAQI: 120, predicted6hAQI: 145, predicted24hAQI: 165 },
    { name: "Commercial Market", lat: 33.6400, lon: 73.0700, currentAQI: 135, predicted6hAQI: 160, predicted24hAQI: 185 },
    { name: "Bahria Town", lat: 33.5200, lon: 73.1200, currentAQI: 80, predicted6hAQI: 100, predicted24hAQI: 120 },
    { name: "Murree Road", lat: 33.6200, lon: 73.0800, currentAQI: 155, predicted6hAQI: 180, predicted24hAQI: 205 },
  ],

  Sialkot: [
    { name: "Cantt", lat: 32.5000, lon: 74.5400, currentAQI: 90, predicted6hAQI: 110, predicted24hAQI: 130 },
    { name: "Paris Road", lat: 32.4950, lon: 74.5250, currentAQI: 120, predicted6hAQI: 145, predicted24hAQI: 165 },
    { name: "Daska Road", lat: 32.4700, lon: 74.5000, currentAQI: 145, predicted6hAQI: 170, predicted24hAQI: 195 },
    { name: "Industrial Area", lat: 32.5150, lon: 74.5750, currentAQI: 180, predicted6hAQI: 210, predicted24hAQI: 240 },
  ],

  Gujranwala: [
    { name: "Satellite Town", lat: 32.1800, lon: 74.1900, currentAQI: 125, predicted6hAQI: 150, predicted24hAQI: 175 },
    { name: "Model Town", lat: 32.1650, lon: 74.1850, currentAQI: 110, predicted6hAQI: 135, predicted24hAQI: 155 },
    { name: "GT Road", lat: 32.1900, lon: 74.2000, currentAQI: 160, predicted6hAQI: 185, predicted24hAQI: 215 },
    { name: "Industrial Estate", lat: 32.2200, lon: 74.2300, currentAQI: 195, predicted6hAQI: 225, predicted24hAQI: 255 },
  ],
};
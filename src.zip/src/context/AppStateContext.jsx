import React, { createContext, useState, useContext } from "react";
import { useRealtimeData } from "../hooks/useRealtimeData";

const AppStateContext = createContext();

export const predefinedCities = [
  { city: "Lahore", lat: 31.5204, lon: 74.3587, display_name: "Lahore, Punjab, Pakistan" },
  { city: "Karachi", lat: 24.8607, lon: 67.0011, display_name: "Karachi, Sindh, Pakistan" },
  { city: "Islamabad", lat: 33.6844, lon: 73.0479, display_name: "Islamabad, Pakistan" },
  { city: "Rawalpindi", lat: 33.5651, lon: 73.0169, display_name: "Rawalpindi, Punjab, Pakistan" },
  { city: "Faisalabad", lat: 31.4181, lon: 73.0776, display_name: "Faisalabad, Punjab, Pakistan" },
  { city: "Multan", lat: 30.1968, lon: 71.4681, display_name: "Multan, Punjab, Pakistan" },
  { city: "Peshawar", lat: 34.0151, lon: 71.5249, display_name: "Peshawar, KPK, Pakistan" },
  { city: "Quetta", lat: 30.1798, lon: 66.9750, display_name: "Quetta, Balochistan, Pakistan" },
  { city: "Sialkot", lat: 32.4945, lon: 74.5229, display_name: "Sialkot, Punjab, Pakistan" },
  { city: "Gujranwala", lat: 32.1877, lon: 74.1945, display_name: "Gujranwala, Punjab, Pakistan" },
];

export const AppStateProvider = ({ children }) => {
  const [selectedCity, setSelectedCity] = useState(predefinedCities[0]);
  const realtimeData = useRealtimeData(selectedCity.lat, selectedCity.lon);

  return (
    <AppStateContext.Provider
      value={{
        selectedCity,
        setSelectedCity,
        realtimeData,
        predefinedCities,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => useContext(AppStateContext);
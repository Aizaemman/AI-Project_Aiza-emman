import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
  },
});

export const predictRisk = async (data) => {
  const response = await api.post('/predict', data);
  return response.data;
};

export const chatWithAI = async (message) => {
  const response = await api.post('/chat', { message });
  return response.data;
};

export const predictFutureAQI = async (data) => {
  const response = await api.post('/predict_future', data);
  return response.data;
};

export default api;

import axios from 'axios';

const WAQI_API_KEY = import.meta.env.VITE_WAQI_API_KEY;
const BASE_URL = 'https://api.waqi.info/feed';

export const getCityAQI = async (city) => {
  if (!WAQI_API_KEY) throw new Error("WAQI API key is missing");
  const response = await axios.get(`${BASE_URL}/${city}/?token=${WAQI_API_KEY}`);
  if (response.data.status !== "ok") {
    throw new Error(response.data.data);
  }
  return response.data.data;
};

export const getAQIByCoordinates = async (lat, lon) => {
  if (!WAQI_API_KEY) throw new Error("WAQI API key is missing");
  const response = await axios.get(`${BASE_URL}/geo:${lat};${lon}/?token=${WAQI_API_KEY}`);
  if (response.data.status !== "ok") {
    throw new Error(response.data.data);
  }
  return response.data.data;
};

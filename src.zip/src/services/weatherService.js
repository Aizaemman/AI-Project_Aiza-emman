import axios from 'axios';

const OPENWEATHER_API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY;
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export const getCurrentWeather = async (lat, lon) => {
  if (!OPENWEATHER_API_KEY) throw new Error("OpenWeather API key is missing");
  const response = await axios.get(`${BASE_URL}/weather?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric`);
  return response.data;
};

export const getAirPollution = async (lat, lon) => {
  if (!OPENWEATHER_API_KEY) throw new Error("OpenWeather API key is missing");
  const response = await axios.get(`${BASE_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}`);
  return response.data;
};

export const getAirPollutionForecast = async (lat, lon) => {
  if (!OPENWEATHER_API_KEY) throw new Error("OpenWeather API key is missing");
  const response = await axios.get(`${BASE_URL}/air_pollution/forecast?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}`);
  return response.data;
};
